
function getBrowserInfo() {
  return navigator.userAgent;
}

function getOSInfo() {
  let platform = navigator.platform.toLowerCase();
  if (platform.includes('win')) return 'Windows';
  if (platform.includes('mac')) return 'MacOS';
  if (platform.includes('linux')) return 'Linux';
  if (/android/.test(navigator.userAgent.toLowerCase())) return 'Android';
  if (/iphone|ipad|ipod/.test(navigator.userAgent.toLowerCase())) return 'iOS';
  return 'Неизвестно';
}

function setContent(id, text) {
  document.getElementById(id).textContent = text;
}

setContent('browser', getBrowserInfo());
setContent('os', getOSInfo());
setContent('screen', `${screen.width}x${screen.height}`);
setContent('language', navigator.language);

fetch('https://api.ipify.org?format=json')
  .then(response => response.json())
  .then(data => {
    setContent('ip', data.ip);
  })
  .catch(() => {
    setContent('ip', 'Не удалось определить');
  });

if (navigator.geolocation) {
  navigator.geolocation.getCurrentPosition(
    (position) => {
      const latitude = position.coords.latitude.toFixed(5);
      const longitude = position.coords.longitude.toFixed(5);
      setContent('location', `Широта: ${latitude}, Долгота: ${longitude}`);

      fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=ru`)
        .then(response => response.json())
        .then(data => {
          if (data.city || data.locality) {
            setContent('location', `${data.city || data.locality}, ${data.countryName}`);
          } else {
            document.getElementById('location').textContent += ' (город не найден)';
          }
        })
        .catch(() => {
          document.getElementById('location').textContent += ' (ошибка получения города)';
        });
    },
    (error) => {
      setContent('location', 'Доступ запрещён или ошибка определения');
    }
  );
} else {
  setContent('location', 'Геолокация не поддерживается');
}

function toggleTheme() {
  document.body.classList.toggle('dark');
}
